class Employee
{
	empId:number;
	empName:String;
	empSal:Numebr;
	static empPF:number=12;
	static empComp:String="capgemini";
}

let e1=new Employee();
e1.empId=112081;
e1.empName="Rajib";
e1.empSal=1000;

console.log(" ID : "+e1.empId+" Name: "+ e1.empName +" SALARY :"e1.empSal+" PF :"+Employee.empPF +" comp :"+Employee.empComp);
