package com.capgemini.hotel.bean;

public class RoomBooking {

    //private	CustomerBean cust;
	private String roomno;
	private String roomtype;
//	public CustomerBean getCust() {
//		return cust;
//	}
//	public void setCust(CustomerBean cust) {
//		this.cust = cust;
//	}
	public String getRoomno() {
		return roomno;
	}
	public void setRoomno(String roomno) {
		this.roomno = roomno;
	}
	public String getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}
	@Override
	public String toString() {
		return "RoomBooking [ roomno=" + roomno + ", roomtype=" + roomtype + "]";
	}
	public RoomBooking( String roomno, String roomtype) {
		super();
		
		this.roomno = roomno;
		this.roomtype = roomtype;
	}
	public RoomBooking() {
		
	}
	
	
	
	
	
	
}
