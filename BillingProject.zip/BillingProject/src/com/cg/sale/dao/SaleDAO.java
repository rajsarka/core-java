package com.cg.sale.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.sale.bean.Sale;
import com.cg.sale.exception.SaleException;

public class SaleDAO implements ISaleDAO {
	public static Map<Integer,Sale> sales= new HashMap<Integer,Sale>();
	public Sale getProduct(int id ) throws SaleException{
		
		
		return null;
		
		
	}
}
