let log=function (message)
{
	console.log(message);
	}
	
	log("Welcome ");
	
	//-----------------------------
	
	let dolog=(message)=>console.log(message);
	dolog("welcome using arrow function syntax");
	
	//---------------------------
	
	
	let dolog2=()=>console.log("Empty msg");
	dolog2();
	
	//----------------------
	function getSum(numOne:number,numTwo: number):number
	{
	return(numOne+numTwo);
	
	}
	
	console.log("Result is:"+getSum(7,8));
	var add=getSum(60,20);
	console.log("Another Result:"+add);
	
	//-------------------------------var args--------
	
	function sumAll(...nums:number[])
	{
	let sum:number=0;
	for(let x of nums)
	{
		sum=sum+x;
	}
	console.log("Summation of all numbers:"+sum);
	}
	sumAll(30,45);
	sumAll(30,20,15,48);
	
	//--------------------------------
	function doGet(one:number,two=5,three?:number):void
	{
	console.log("first parameter : "+one);
	console.log("2nd parameter : "+two);
	console.log("3rd parameter : "+three);
		console.log("-------------------------");
	}
	doGet(10);
	doGet(10,20);
	doGet(10,20,30);
	
	