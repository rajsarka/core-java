package com.capgemini.hotel.service;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public interface IHotelService {

	
	
	
	
	
	int addCustomerDetails(CustomerBean bean);
	CustomerBean getBookingDetails(int CustomerId);
	
	public RoomBooking getRoomDetails(int roomno);
	
	
	
}
