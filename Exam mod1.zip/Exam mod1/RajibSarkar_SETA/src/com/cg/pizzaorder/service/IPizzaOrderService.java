package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.pizzaexception.PizzaException;

public interface IPizzaOrderService {

	public PizzaOrder placeOrder(Customer Customer,PizzaOrder pizza) throws PizzaException;
	
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
	
	
}
