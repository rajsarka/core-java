package com.capgemini.hotel.service;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.CustomerBookingDAO;
import com.capgemini.hotel.dao.ICustomerBookingDAO;


public class HotelService implements IHotelService {

	
	
	ICustomerBookingDAO dao;
	public HotelService()
	{
		dao=new CustomerBookingDAO();
	}
	
	
	@Override
	public int addCustomerDetails(CustomerBean bean) {
		
		return dao.addCustomerDetails(bean);
	}

	@Override
	public CustomerBean getBookingDetails(int CustomerId) {
	
		return dao.getBookingDetails(CustomerId);
	}

	public RoomBooking getRoomDetails(int roomno)
	 {
		 return dao.getRoomDetails(roomno);
	 }
	
}
