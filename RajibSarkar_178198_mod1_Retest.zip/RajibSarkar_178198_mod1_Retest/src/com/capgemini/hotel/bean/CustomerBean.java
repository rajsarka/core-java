package com.capgemini.hotel.bean;

public class CustomerBean {

	private String name;
	private String email;
	private String Address;
	private String mobile;
	private int CustomerId;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public int getCustomerId() {
		return CustomerId;
	}
	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}
	@Override
	public String toString() {
		return "CustomerBean [name=" + name + ", email=" + email + ", Address=" + Address + ", mobile=" + mobile
				+ ", CustomerId=" + CustomerId + "]";
	}
	public CustomerBean() {
		
	}
	public CustomerBean(String name, String email, String address, String mobile, int customerId) {
		super();
		this.name = name;
		this.email = email;
		Address = address;
		this.mobile = mobile;
		CustomerId = customerId;
	}
	
	
	
	
	
}
