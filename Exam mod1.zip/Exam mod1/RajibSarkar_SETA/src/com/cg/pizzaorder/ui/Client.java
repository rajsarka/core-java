package com.cg.pizzaorder.ui;

import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.pizzaexception.PizzaException;
import com.cg.pizzaorder.service.PizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderValidation;



public class Client {

	public static void main(String[] args) {
		
		int option;
		Scanner sc=new Scanner(System.in);
		PizzaOrderService service=new PizzaOrderService();
		PizzaOrderValidation validator = new PizzaOrderValidation();
		
		/*do {*/
			
			
		 
		 do {
			 Customer cus= new Customer();
				PizzaOrder piz=new PizzaOrder();
				
				
				System.out.println("1. Place Order");
				System.out.println("2. Display Order");
				System.out.println("3. Exit");
				
			 option = sc.nextInt();
			 
			 
		 switch(option) {
		 
		 case 1:
			 try {
			 System.out.println("Enter the name of the customer");
			 String name=sc.next();
			 System.out.println("Enter customer city");
			 String add=sc.next();
			 System.out.println("Enter customer phone number");
			 String mob=sc.next();
			 if(validator.getValidatePhone(mob) == false)
					throw new PizzaException("Enter your Valid Phone number.");
			 
			 System.out.println("Type of Pizza Topping preferred");
			 System.out.println("Pizza Topping : Capsicum, Price : 30 Rs.");
			 System.out.println("Pizza Topping : Mushroom, Price : 50 Rs.");
			 System.out.println("Pizza Topping : Jalapeno, Price : 70 Rs.");
			 
			 System.out.println("Pizza Topping : Paneer, Price : 85 Rs.");
			
			 String topp=sc.next();
			 
			if(topp.equals("Capsicum"))
			{
				piz.setTopprice(30);
			}
			else if(topp.equals("Mushroom"))
			{
				piz.setTopprice(50);
			}
			else if(topp.equals("Jalapeno"))
			{
				piz.setTopprice(70);
			}
			else
			{
				piz.setTopprice(85);
			}
			 cus.setAddress(add);
			 cus.setCustName(name);
			 cus.setPhone(mob);
			 
			Random ran =new Random();
			int a = ran.nextInt(90000);
			piz.setOrderId(a);
				 
				 
				Random ran2=new Random();
				int b=ran2.nextInt(5000);
				piz.setCustomerId(b);
				
			 piz.setSaleDate(LocalDate.now());
			 
			 int bprice=350;
			 piz.setTotalPrice(bprice+piz.getTopprice());
			 
			
				piz=service.placeOrder(cus, piz);
			
		 System.out.println("Pizza Order successfully placed with order id : " + piz.getOrderId());
		 }
		 catch (PizzaException e) {
				
				System.out.println(e.getMessage());;
			}
			 
			 
			 break;
			 
		 case 2:
			 
			 try {
					System.out.println("Enter your order id");
					 int orderid=sc.nextInt();
					 piz=service.getOrderDetails(orderid);
					 System.out.println("1:Order ID: "+piz.getOrderId()+"\n"+"2:Customer Id"+piz.getCustomerId()+"\n"+"Total Amount"+piz.getTotalPrice()+"\n");
			 }
			 catch(PizzaException e1)
			 {
				 System.out.println(e1.getMessage());
			 }
					 break;
					 
					 case 3:
						 System.exit(0);
					 
			 
		 
		 
		 
		 
	}

}while(option != 3);
	}
}

