package com.cg.sale.ui;

import java.util.Scanner;

import com.cg.sale.service.ProductService;

public class Client {

	public static void main(String[] args) {
		String id;
		Scanner sc=new Scanner(System.in);
		ProductService service= new IProductService();
		
	}

}
