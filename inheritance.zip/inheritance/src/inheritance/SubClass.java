package inheritance;

public class SubClass extends SuperClass {

private String name;

public SubClass()
{
	this.name ="capgemini";
	
}

public SubClass(int id,String name)
{
	super(id);
	this.name=name;
}
 public String show()
 {
	 return super.show() + "value of Name " + this.name;
 }























}
