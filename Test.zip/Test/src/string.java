

public class string {
public static void main(String args) {
}
}