import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SortMap {
	public static void main(String args[]) {
Map<String, Integer> hm = new HashMap<String, Integer>();
hm.put("John Doe", 1);
hm.put("Tom Smith", 2);

System.out.println(hm);
	
	List<Integer> list1 = new ArrayList<Integer>(hm.values());
	for(Integer i: list1)
{System.out.println(i);
		
}
	List<String> list2 = new ArrayList<String>(hm.keySet());
	for(String s: list2)
{System.out.println(s);
		
}
	
	}
}