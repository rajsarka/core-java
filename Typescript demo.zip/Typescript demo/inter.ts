interface IEmployee
{
	firstName:string;
	lastName:string;
	
	
}

let e2:IEmployee=
{
firstName: "Rajib",
	lastName:"Sarkar"
	}
	
	console.log("Full Name: "+ this.e2.firstName+ "  "+  this.e2.lastName);