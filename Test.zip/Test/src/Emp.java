


	

import java.util.*;

class Emp implements Comparable {
	int EmpID;
	String Ename;
	double Sal;
	static int i;

	public Emp() {
		EmpID = i++;
		Ename = "Unknown";
		Sal = 0.0;
	}

	public Emp(String ename, double sal) {
		EmpID = i++;
		Ename = ename;
		Sal = sal;
	}

	public String toString() {
		return "EmpID : " + EmpID + "\t" + "Ename : " + Ename + "\t" + "Sal : "
				+ Sal;
	}

	public int compareTo(Object o) {
		if (this.Sal == ((Emp) o).Sal)
			return 0;
		else if (this.Sal > ((Emp) o).Sal)
			return 1;
		else
			return -1;
	}
}




