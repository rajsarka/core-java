package com.cg.pizzaorder.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PizzaOrderValidation {

	public boolean getValidatePhone(String phoneNo) {
		if(phoneNo==null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("^[0-9]{10}$");
		Matcher mat = pat.matcher(phoneNo);
		if(mat.matches())
			return true;
		else
			return false;
	}
	
	
}
