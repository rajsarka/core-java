package com.cg.pizzaorder.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.pizzaexception.PizzaException;
import com.cg.pizzaorder.service.PizzaOrderValidation;



public class PizzaTest {
	@Test
	public void testMethod1() {
		
		PizzaOrderValidation validator= new PizzaOrderValidation();
		
		String mob="8981120269";
		boolean actual= validator.getValidatePhone(mob);
		boolean expected=true;
		
		assertEquals(expected, actual);
	}
	@Test
	public void testMethod2() {
		
		PizzaOrderValidation validator= new PizzaOrderValidation();
		
		String mob="92340423";
		boolean actual= validator.getValidatePhone(mob);
		boolean expected=false;
		assertEquals(expected, actual);
	}
	@Test
	public void testMethod3() {
		
		PizzaOrderValidation validator= new PizzaOrderValidation();
		
		String mob="ertr34";
		boolean actual= validator.getValidatePhone(mob);
		boolean expected=false;
		assertEquals(expected, actual);
	}
	
	
	
	
}
