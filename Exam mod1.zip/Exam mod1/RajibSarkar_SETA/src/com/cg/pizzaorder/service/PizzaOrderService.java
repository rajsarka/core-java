package com.cg.pizzaorder.service;


import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.pizzaexception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {

	PizzaOrderDAO dao;
	public PizzaOrderService ()
	{
		dao=new PizzaOrderDAO();
	}
	
	@Override
	public PizzaOrder placeOrder(Customer cus, PizzaOrder piz) throws PizzaException {
		
		return dao.placeOrder(cus,piz);
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		
		return dao.getOrderDetails(orderid);
	}

}
