package com.capgemini.hotel.exception;

public class HotelException extends Exception{

	
	public HotelException() {
		super();
		
	}
	public HotelException(String s) {
		super(s);
		
	}
	
	
	
}
