function validateQualification1(){

var valQuall=window.document.formReg.qual;
var graArr1=new Array("B.Tech","B.sc","B.a","B.com","BCA");
for(var i=1;i<graArr1.length;i++)
{
valQuall.options[i]=new Option(graArr1[i],graArr1[i]);
}
}

//*******************************

function validateQualification2(){

var valQual2=window.document.formReg.qual;
var graArr2=new Array("M.tech","M.sc","M.a","M.com","MCA");
for(var i=1;i<graArr2.length;i++)
{
valQual2.options[i]=new Option(graArr2[i],graArr2[i]);
}
}

//**************************************

function validateAllData(){

var fname=window.document.formReg.fnameid.value;
var dob2=window.document.formReg.dob.value;
var mobd=window.document.formReg.ph.value;
var maild=window.document.formReg.mail.value;
var graddata=window.document.formReg.gradl.value;
var qualdata=window.document.formReg.qual.value

var datenow=new Date();
var dateyr=eval(dob2.substring(6,10));
var age=datenow.getFullYear()-dateyr;

var cgWinObj=window.open("","CGWindow","Width=500,height=600");
cgWinObj.document.write("<body bgcolor='orange'>");
cgWinObj.document.write("<h2> Name </h2>"+fname);
cgWinObj.document.write("<h2>Mobile No.</h2>"+mobd);
cgWinObj.document.write("<h2> AGE </h2>"+age);
cgWinObj.document.write("<h2>Email ID </h2>"+maild);
cgWinObj.document.write("<h2>Graduation Level </h2>"+graddata);
cgWinObj.document.write("<h2>Qualification: </h2>"+qualdata);




}
 function show()
 {
	 alert("submitted");
 }