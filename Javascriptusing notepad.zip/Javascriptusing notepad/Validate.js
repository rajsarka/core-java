function validateAllData()
{
var fnameData=window.document.formRegister.txtFname.value;
var pwdData=window.document.formRegister.txtPwd.value;
var cpwdData=window.document.formRegister.txtCPwd.value;

if(pwdData!=cpwdData)
{
	alert("Password and confirm password should be same");
	return false

}
var cgWinObj=window.open("","CGWindow","width=400,height=300");
cgWinObj.document.write("<body bgcolor='cyan'>");
cgWinObj.document.write("<h2>Welcome :</h2>"+fnameData);
cgWinObj.document.write("</body>");
return true;
}