var dom=new Array("JEE",".NET");
var mod=new Array();
mod[0]=new Array("Core-Java","Servlet-JSP","Spring");
mod[1]=new Array("C#","ADO.NET","ASP.NET");
mod[2]=new Array("---");

function populateDom(){
var domObj=window.document.formPro.dwndom;
for(var i=0;i<dom.length;i++)
{
domObj.options[i]=new Option(dom[i]);
}


}

//***************


function populateMod()
{
	var domObj=window.document.formPro.dwndom;
	var modObj=window.document.formPro.dwnmod;
	
	var indexOfDomainSelected=domObj.selectedIndex;
	for(var j=0;j<mod.length;j++)
	{
	modObj.options[j]=new Option(mod[indexOfDomainSelected][j],mod[indexOfDomainSelected][j]);
	
	}
}

//******


function getTotal()

{
	

var mptno=eval(window.document.formPro.mpt.value);
var mttno=eval(window.document.formPro.mtt.value);
var assgno=eval(window.document.formPro.assi.value);

var total= eval(mptno+mttno+assgno);

alert("Total marks : "+total);




}