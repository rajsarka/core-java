package com.capgemini.hotel.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;


public class CustomerBookingDAO implements ICustomerBookingDAO{
	
	
	
	
	Map<Integer,CustomerBean> customerDetails=new HashMap<>();
    static Map<Integer,RoomBooking> roomDetails=new HashMap<>();
	
	
   static {
		roomDetails.put(101,new RoomBooking( "101","AC_SINGLE"));
		roomDetails.put(102,new RoomBooking("102","AC_SINGLE"));
		roomDetails.put(103,new RoomBooking("103","AC_DOUBLE"));
		roomDetails.put(201,new RoomBooking("201","NONAC_SINGLE"));
		roomDetails.put(202,new RoomBooking("202","NONAC_SINGLE"));
		roomDetails.put(203,new RoomBooking("203","NONAC_DOUBLE"));
		
		
    }
			
	
	
	public RoomBooking getRoomDetails(int roomno) {
	return roomDetails.get(roomno);
		
		
	}

	@Override
	public int addCustomerDetails(CustomerBean bean) {
		
		customerDetails.put(bean.getCustomerId(), bean);
		
		return bean.getCustomerId();
	}

	@Override
	public CustomerBean getBookingDetails(int CustomerId) {
		CustomerBean rb=customerDetails.get(CustomerId);
		return rb;
	}

}
