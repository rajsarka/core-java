
public class list<I> {
void ArrayList(){
}
}