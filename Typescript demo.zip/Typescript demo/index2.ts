<html>
	<head>
		<script>
		function getData(msg)
		{
		console.log(msg)
		}
		var=msg='hello world';
		getData(msg);
		</script>
	</head>
	<body>
	</body>
	
</html>