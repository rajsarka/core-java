import java.util.*;

public class Employee {

	
		private int age;
		private String name;

		public void setAge(int age) {
			this.age = age;
		}

		public int getAge() {
			return this.age;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getName() {
			return this.name;
		}

	}

	/* The below given comparator compares employees on the basis of their name */

class NameComparator implements Comparator {

	public int compare(Object emp1, Object emp2) {

		// parameter are of type Object, so we have to downcast it to Employee
		// objects

	String emp1Name = ((Employee) emp1).getName();
		String emp2Name = ((Employee) emp2).getName();

		return emp1Name.compareTo(emp2Name);
}
}

/*
 * This Java comparator example compares employees on the basis of
 * 
 * their name and sort it in that order.
 */



