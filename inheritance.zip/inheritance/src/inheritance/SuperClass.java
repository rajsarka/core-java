package inheritance;

public class SuperClass {

	private int id;

public SuperClass()
{
	this.id=100;

}
public SuperClass(int num)
{
	this.id=num;
}
public String show()
{
	return " value of ID: " + this.id;
}
}