package inheritance;

public class Dog extends Inheritance {
	void run()
	{
		System.out.println("i am in dog class");
	}

}
