package com.capgemini.hotel.ui;

import java.util.Random;
import java.util.Scanner;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.HotelDaoValidation;
import com.capgemini.hotel.exception.HotelException;
import com.capgemini.hotel.service.HotelService;





public class Client {

	public static void main(String[] args) {
		
		
		int option;
		Scanner sc=new Scanner(System.in);
		HotelService service=new HotelService();
		HotelDaoValidation validator = new HotelDaoValidation();
		
    do {
			
	CustomerBean Bean=new CustomerBean();
	RoomBooking Room=new RoomBooking();
			
    System.out.println("1. Book Room");
	System.out.println("2. View Booking Details ");
	System.out.println("3. Exit");
			
    option = sc.nextInt();
		
    	switch(option) 
		 {
    	case 1:
    		try {
    			System.out.println("Enter Customer Name");
    			String name=sc.next();
    			if(validator.getValidateName(name) == false)
					throw new HotelException("Customer Name start should be  Capital.(Name length should be 3-20 alphabet)");
    			
    			System.out.println("Enter Email Id");
    			String mail=sc.next();
    			
    			System.out.println("Enter Customer City");
    			String add=sc.next();
    			if(validator.getValidateAddress(add) == false)
					throw new HotelException("You Enter Invalid Address.");
				
    			System.out.println("Enter Mobile No.");
    			String mobno=sc.next();
    			if(validator.getValidatePhone(mobno) == false)
					throw new HotelException("Enter your Valid Mobile number.");
    			
    			System.out.println("Enter Room No");
    			String roomno=sc.next();
    			System.out.println("Enter Room Type");
    			String roomtype=sc.next();
    			
    			    Random ran =new Random();
					int a = ran.nextInt(90000);
					Bean.setCustomerId(a);
					
					Bean.setName(name);
					Bean.setEmail(mail);
					Bean.setAddress(add);
					Bean.setMobile(mobno);
					
					Room.setRoomno(roomno);
					Room.setRoomtype(roomtype);
					
					
					int id=service.addCustomerDetails(Bean);
					System.out.println("Your Room has been successfully booked,your Customer Id is: "+id);	
					
    			
    		}
    		 catch(Exception e) 
			 {
			 System.out.println(e);
		     }
    		
    		break;
    	case 2:
    	
    			
    			 System.out.println("Enter Customer ID");
				 int un=sc.nextInt();
				 System.out.println("Enter Room no");
				 int rn=sc.nextInt();
				 Bean=service.getBookingDetails(un);
    			System.out.println("Name of the Customer: "+Bean.getName());
    			
				 
    			
    			Room=service.getRoomDetails(rn);
    			System.out.println("Name of the Customer: "+Room.getRoomtype());
    			
    			
    	
    		
    		
    		break;
    		
    	case 3:
    		System.exit(0);
		 
		 }
			
			
		}while(option!=4);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
