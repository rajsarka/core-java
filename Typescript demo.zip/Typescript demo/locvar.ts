//local variable
for(let num=1;num<3;num++)
{
console.log("<br/>local num: " +num);
}
console.log("_________________");

var num1=120;
if(true)
{
var num1=130;
console.log("Num1= "+num1);
}
console.log("Num1="+num1);
console("----------------------");