package com.cg.pizzaorder.bean;

import java.time.LocalDate;

public class PizzaOrder {

	private int orderId;
	private int customerId;
	private int topprice;
	
	public int getTopprice() {
		return topprice;
	}
	public void setTopprice(int topprice) {
		this.topprice = topprice;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	private double totalPrice;
	private LocalDate saleDate;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public LocalDate getSaleDate() {
		return saleDate;
	}
	public void setSaleDate(LocalDate saleDate) {
		this.saleDate = saleDate;
	}
	
	
	@Override
	public String toString() {
		return "PizzaOrder [orderId=" + orderId + "  totalPrice=" + totalPrice + "  + customerId ]";
	}
	public PizzaOrder(int orderId, int customerId, double totalPrice) {
		super();
		this.orderId = orderId;
	this.customerId = customerId;
		this.totalPrice = totalPrice;
	}
	public PizzaOrder() {
		
	}
	
	
	
	
	
	
}
