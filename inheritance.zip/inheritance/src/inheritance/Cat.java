package inheritance;

public class Cat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Dog obj=new Dog();
obj.run();


	}

}
