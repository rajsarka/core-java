package inheritance;

public class Inheritance {
void run()
{
	System.out.println("i am in run");
	
}
}
