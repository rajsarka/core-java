import java.util.*;

public class HashMapDemo2 {

	public static void main(String[] args) {
		HashMap m=new HashMap();
		m.put("Raja", 700);
		m.put("Rajib",800);
		m.put("Amal", 200);
		m.put("Bimal", 500);
		
		// returning map
		
		System.out.println(m);
		
		
		// returning old value of raja
		
		System.out.println(m.put("Raja",1000));
		System.out.println(m);
		
		//below gives keys 
		
		Set s=m.keySet();   // s is a collection not map
		System.out.println(s);
	
		
		//below gives values 
		
		Collection c=m.values();
		System.out.println(c);
		
		
		//printing entry object
		
		Set s1= m.entrySet();
		System.out.println(s1);
		
		
}
}