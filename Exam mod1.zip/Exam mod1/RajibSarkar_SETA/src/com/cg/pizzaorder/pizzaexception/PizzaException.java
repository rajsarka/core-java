package com.cg.pizzaorder.pizzaexception;

public class PizzaException extends Exception {

	public PizzaException() {
		super();
		
	}
	public PizzaException(String s) {
		super(s);
		
	}
}
