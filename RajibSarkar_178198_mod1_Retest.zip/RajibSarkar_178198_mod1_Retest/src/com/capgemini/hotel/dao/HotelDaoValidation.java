package com.capgemini.hotel.dao;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HotelDaoValidation {

	public boolean getValidateName(String name) {

		if(name == null)
			throw new NullPointerException();
		
		Pattern pat = Pattern.compile("^[A-Z][a-z]{2,21}$");
		Matcher mat = pat.matcher(name);
		if(mat.matches())
			return true;
		else
			return false;
	}

	public boolean getValidateAddress(String address) {
		if(address == null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("^[A-Za-z0-9]{4,51}$");
		Matcher mat = pat.matcher(address);
		if(mat.matches())
			return true;
		else			
			return false;
	}

	public boolean getValidatePhone(String phoneNo) {
		if(phoneNo==null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher mat = pat.matcher(phoneNo);
		if(mat.matches())
			return true;
		else
			return false;
	}

	
	
}
