package com.cg.pizzaorder.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.pizzaexception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO{
	
	
	Map<Integer,PizzaOrder> pizzaEntry = new HashMap<>();
	Map<Integer,Customer> customerEntry=new HashMap<>();
	
	
			
			
			
;	@Override
	public PizzaOrder placeOrder(Customer cus, PizzaOrder pizza) throws PizzaException {
	
	
	pizzaEntry.put(pizza.getOrderId(), pizza);
	customerEntry.put(pizza.getCustomerId(), cus);
	
		return pizza;
		
		
	}



		@Override
		public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
			PizzaOrder piz=pizzaEntry.get(orderid);
			return piz;
		}

}
